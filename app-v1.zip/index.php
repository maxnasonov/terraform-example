<?php
    echo 'It works!';
?>
